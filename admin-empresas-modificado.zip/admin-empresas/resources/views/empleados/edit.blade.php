@extends('layouts.app')
@section('title', 'Editar Empleado')
@section('content')
    <div class="container">
        <h1>Editar Empleado</h1>
        <form action="{{ route('empleados.update', $empleado->id) }}" method="POST" class="mt-4">
            @csrf
            @method('PATCH')
            <div class="mb-4">
                <label for="nombre" class="block text-gray-700">Nombre:</label>
                <input type="text" name="nombre" id="nombre" value="{{ old('nombre', $empleado->nombre) }}" class="w-full border rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="cargo" class="block text-gray-700">Cargo:</label>
                <input type="text" name="cargo" id="cargo" value="{{ old('cargo', $empleado->cargo) }}" class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label for="salario" class="block text-gray-700">Salario:</label>
                <input type="number" step="0.01" name="salario" id="salario" value="{{ old('salario', $empleado->salario) }}" class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label for="empresa_id" class="block text-gray-700">Empresa:</label>
                <select name="empresa_id" id="empresa_id" class="w-full border rounded px-3 py-2" required>
                    @foreach($empresas as $empresa)
                        <option value="{{ $empresa->id }}" {{ $empresa->id == old('empresa_id', $empleado->empresa_id) ? 'selected' : '' }}>
                            {{ $empresa->nombre }}
                        </option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Actualizar Empleado</button>
        </form>
    </div>
@endsection

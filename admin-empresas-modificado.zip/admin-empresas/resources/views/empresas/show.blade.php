@extends('layouts.app')
@section('title', 'Ver Empresa')
@section('content')
    <div class="container">
        <h1>Empresa: {{ $empresa->nombre }}</h1>
        <p><strong>Dirección:</strong> {{ $empresa->direccion }}</p>
        <p><strong>Teléfono:</strong> {{ $empresa->telefono }}</p>
        <p><strong>Email:</strong> {{ $empresa->email }}</p>
        <a href="{{ route('empresas.edit', $empresa->id) }}" class="inline-block mt-4 bg-yellow-500 text-white px-3 py-2 rounded">Editar</a>
        <a href="{{ route('empresas.index') }}" class="inline-block mt-4 ml-2 bg-gray-300 px-3 py-2 rounded">Volver</a>
    </div>
@endsection

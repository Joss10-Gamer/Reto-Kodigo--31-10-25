@extends('layouts.app')
@section('title', 'Editar Empresa')
@section('content')
    <div class="container">
        <h1>Editar Empresa</h1>
        <form action="{{ route('empresas.update', $empresa->id) }}" method="POST" class="mt-4">
            @csrf
            @method('PATCH')
            <div class="mb-4">
                <label for="nombre" class="block text-gray-700">Nombre:</label>
                <input type="text" name="nombre" id="nombre" value="{{ old('nombre', $empresa->nombre) }}" class="w-full border rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="direccion" class="block text-gray-700">Dirección:</label>
                <input type="text" name="direccion" id="direccion" value="{{ old('direccion', $empresa->direccion) }}" class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label for="telefono" class="block text-gray-700">Teléfono:</label>
                <input type="text" name="telefono" id="telefono" value="{{ old('telefono', $empresa->telefono) }}" class="w-full border rounded px-3 py-2">
            </div>
            <div class="mb-4">
                <label for="email" class="block text-gray-700">Email:</label>
                <input type="email" name="email" id="email" value="{{ old('email', $empresa->email) }}" class="w-full border rounded px-3 py-2">
            </div>
            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Actualizar Empresa</button>
        </form>
    </div>
@endsection

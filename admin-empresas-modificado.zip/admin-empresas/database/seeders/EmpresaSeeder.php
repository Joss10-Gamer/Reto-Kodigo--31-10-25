<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Empresa;

class EmpresaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Empresa::create([
            'nombre' => 'Tech Solutions',
            'direccion' => '123 Tech Street',
            'telefono' => '555-1234',
        ]);
        Empresa::create([
            'nombre' => 'Propi',
            'direccion' => 'Torre Futura, San Salvador',
            'telefono' => '7923-4643',
        ]);
        Empresa::create([
            'nombre' => 'Innovatech',
            'direccion' => '456 Innovation Ave',
            'telefono' => '555-5678',
        ]);
    }
}

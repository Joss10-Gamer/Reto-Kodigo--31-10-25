<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Empleado;
use App\Models\Empresa;

class EmpleadoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $propi = Empresa::where('nombre', 'Propi')->first();
        $innovatech = Empresa::where('nombre', 'Innovatech')->first();

        Empleado::create([
            'nombre' => 'Juan Perez',
            'cargo' => 'Desarrollador Senior',
            'salario' => 3500.00,
            'empresa_id' => $propi->id,
        ]);

        Empleado::create([
            'nombre' => 'Maria Gomez',
            'cargo' => 'Gerente de Proyectos',
            'salario' => 4500.00,
            'empresa_id' => $innovatech->id,
        ]);

        Empleado::create([
            'nombre' => 'Carlos Ruiz',
            'cargo' => 'Analista de Sistemas',
            'salario' => 3000.00,
            'empresa_id' => $propi->id,
        ]);
    }
}

<!DOCTYPE html>
<html>
<head>
  <title>@yield('title','Logged Panel')</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="p-6 bg-gray-100">
  <nav><a href="{{ route('empresas.index') }}">Empresas</a> | <a href="{{ route('empleados.index') }}">Empleados</a>

  
  <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <a href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </a>
                        </form>

</nav>

  <hr class="my-4">
  @yield('content')
</body>
</html>

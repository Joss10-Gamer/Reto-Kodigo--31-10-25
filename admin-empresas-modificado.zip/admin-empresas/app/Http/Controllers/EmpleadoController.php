<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Empleado;
use App\Models\Empresa;

class EmpleadoController extends Controller
{
    public function index()
    {
        $empleados = Empleado::with('empresa')->get();
        return view('empleados.index', compact('empleados'));
    }

    public function create()
    {
        $empresas = Empresa::all();
        return view('empleados.create', compact('empresas'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nombre' => 'required|string|max:255',
            'cargo' => 'nullable|string|max:255',
            'salario' => 'nullable|numeric',
            'empresa_id' => 'required|exists:empresas,id',
        ]);

        Empleado::create($data);

        return redirect()->route('empleados.index')->with('success', 'Empleado creado exitosamente.');
    }

    public function show(Empleado $empleado)
    {
        $empleado->load('empresa');
        return view('empleados.show', compact('empleado'));
    }

    public function edit(Empleado $empleado)
    {
        $empresas = Empresa::all();
        return view('empleados.edit', compact('empleado','empresas'));
    }

    public function update(Request $request, Empleado $empleado)
    {
        $data = $request->validate([
            'nombre' => 'required|string|max:255',
            'cargo' => 'nullable|string|max:255',
            'salario' => 'nullable|numeric',
            'empresa_id' => 'required|exists:empresas,id',
        ]);

        $empleado->update($data);

        return redirect()->route('empleados.index')->with('success', 'Empleado actualizado exitosamente.');
    }

    public function destroy(Empleado $empleado)
    {
        $empleado->delete();

        return redirect()->route('empleados.index')->with('success', 'Empleado eliminado exitosamente.');
    }

    public function empleadosPorEmpresa($empresaId)
    {
        $empleados = Empleado::where('empresa_id', $empresaId)->get();
        return response()->json($empleados);
    }
}

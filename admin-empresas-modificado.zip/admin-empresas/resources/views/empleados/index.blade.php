@extends('layouts.app')
@section('title', 'Lista de Empleados')
@section('content')
  <h1 class="text-2xl font-bold">Lista de Empleados</h1>
  <a href="{{ route('empleados.create') }}" class="mt-4 inline-block bg-blue-500 text-white px-4 py-2 rounded">Agregar Empleado</a>
  <table class="min-w-full mt-4">
    <thead>
      <tr class="bg-gray-200">
        <th class="py-2">Nombre</th>
        <th class="py-2">Cargo</th>
        <th class="py-2">Salario</th>
        <th class="py-2">Empresa</th>
        <th class="py-2">Acciones</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($empleados as $empleado)
        <tr>
          <td class="border px-4 py-2">{{ $empleado->nombre }}</td>
          <td class="border px-4 py-2">{{ $empleado->cargo }}</td>
          <td class="border px-4 py-2">{{ $empleado->salario }}</td>
          <td class="border px-4 py-2">{{ $empleado->empresa->nombre }}</td>
          <td class="border px-4 py-2">
            <a href="{{ route('empleados.edit', $empleado) }}" class="text-blue-500">Editar</a>
            <form action="{{ route('empleados.destroy', $empleado) }}" method="POST" class="inline">
              @csrf
              @method('DELETE')
              <button type="submit" class="text-red-500">Eliminar</button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
@endsection
@extends('layouts.app')
@section('content')
    <div class="container">
        <h1>Crear Empleado</h1>
        <form action="{{ route('empleados.store') }}" method="POST" class="mt-4">
            @csrf
            <div class="mb-4">
                <label for="nombre" class="block text-gray-700">Nombre:</label>
                <input type="text" name="nombre" id="nombre" class="w-full border rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="cargo" class="block text-gray-700">Cargo:</label>
                <input type="text" name="cargo" id="cargo" class="w-full border rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="salario" class="block text-gray-700">Salario:</label>
                <input type="number" name="salario" id="salario" class="w-full border rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="empresa_id" class="block text-gray-700">Empresa:</label>
                <select name="empresa_id" id="empresa_id" class="w-full border rounded px-3 py-2" required>
                    @foreach($empresas as $empresa)
                        <option value="{{ $empresa->id }}">{{ $empresa->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Crear Empleado</button>
        </form>
    </div>
@endsection
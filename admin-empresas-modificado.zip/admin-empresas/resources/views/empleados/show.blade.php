@extends('layouts.app')
@section('title', 'Ver Empleado')
@section('content')
    <div class="container">
        <h1>Empleado: {{ $empleado->nombre }}</h1>
        <p><strong>Cargo:</strong> {{ $empleado->cargo }}</p>
        <p><strong>Salario:</strong> {{ $empleado->salario }}</p>
        <p><strong>Empresa:</strong> {{ optional($empleado->empresa)->nombre }}</p>
        <a href="{{ route('empleados.edit', $empleado->id) }}" class="inline-block mt-4 bg-yellow-500 text-white px-3 py-2 rounded">Editar</a>
        <a href="{{ route('empleados.index') }}" class="inline-block mt-4 ml-2 bg-gray-300 px-3 py-2 rounded">Volver</a>
    </div>
@endsection

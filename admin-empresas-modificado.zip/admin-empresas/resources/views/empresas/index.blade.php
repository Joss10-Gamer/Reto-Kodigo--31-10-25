@extends('layouts.app')
@section('title', 'Lista de Empresas')
@section('content')
    <h1 class="text-2xl font-bold">Lista de Empresas</h1>
    <a href="{{ route('empresas.create') }}" class="mt-4 inline-block bg-blue-500 text-white px-4 py-2 rounded">Agregar Empresa</a>
    <table class="min-w-full mt-4">
        <thead>
            <tr class="bg-gray-200">
                <th class="py-2">Nombre</th>
                <th class="py-2">Dirección</th>
                <th class="py-2">Teléfono</th>
                <th class="py-2">Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($empresas as $empresa)
                <tr>
                    <td class="border px-4 py-2">{{ $empresa->nombre }}</td>
                    <td class="border px-4 py-2">{{ $empresa->direccion }}</td>
                    <td class="border px-4 py-2">{{ $empresa->telefono }}</td>
                    <td class="border px-4 py-2">
                        <a href="{{ route('empresas.edit', $empresa) }}" class="text-blue-500">Editar</a>
                        <form action="{{ route('empresas.destroy', $empresa) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-500">Eliminar</button>                  
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection